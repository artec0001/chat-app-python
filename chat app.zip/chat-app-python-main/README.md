# chat-app-python
chat app made in python

Portugues brasil 

Execute primeiro o server , depois o client o chat ira funcionar em localhost ou seja so na sua maquina pra funcionar 
em outra maquina precissa instalar o radimin vpn ae vc bota seu ip a onde esta o localhost no server e no client :D

english united states

Run the server first, then the client, the chat will work on localhost, that is, only on your machine to work
on another machine you need to install the radimin vpn and you put your ip where the localhost is on the server and on the client :D
